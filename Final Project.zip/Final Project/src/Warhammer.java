
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.image.Image;

/**
 *
 * @author Ben Spenciner
 */
public class Warhammer extends Weapon {

    private int damage = 3;
    private final StringProperty name = new SimpleStringProperty("Warhammer");
    private char charRepresentation = 'W';
    private Image imgRepresentation = new Image("warhammer.png");

    @Override
    public char getCharRepresentation() {
        return charRepresentation;
    }

    @Override
    public Image getImgRepresentation() {
        return imgRepresentation;
    }

    public void setCharRepresentation(char charRepresentation) {
        this.charRepresentation = charRepresentation;
    }

    public void setImgRepresentation(Image imgRepresentation) {
        this.imgRepresentation = imgRepresentation;
    }
}

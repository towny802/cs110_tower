
/**
 *
 * @author Ben Spenciner
 */
public class Floor {

    public final char charRepresentation = '-';
}

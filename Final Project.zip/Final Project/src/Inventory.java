
import java.util.ArrayList;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author Ben Spenciner
 */
public class Inventory {

    private static GamePiece head;
    private static GamePiece chest;
    private static GamePiece boots;
    private static ArrayList<GamePiece> inventory = new ArrayList<>();

    public static boolean addItem(GamePiece item) {
        switch (inventory.size()) {
            case 5:
                
                inventory.add(item);
                return true;
            case 4:
                
                inventory.add(item);
                return true;
            case 3:
                
                inventory.add(item);
                return true;
            case 2:
                
                inventory.add(item);
                return true;
            case 1:
                
                inventory.add(item);
                return true;
            default:
                return false;
        }
    }

    public static String inventoryToString() {
        return inventory.toString();
    }

    public static GamePiece dropItem(int index) {
        GamePiece temp = inventory.get(index);
        inventory.remove(index);
        return temp;
    }

    public static StringProperty getItem1Property() {
        if (!(inventory.size() <= 0)) {
            return inventory.get(0).getNameProperty();
        }
        StringProperty temp = new SimpleStringProperty(" ");
        return temp;
    }

    public static StringProperty getItem2Property() {
        if (!(inventory.size() <= 1)) {
            return inventory.get(1).getNameProperty();
        }
        StringProperty temp = new SimpleStringProperty(" ");
        return temp;
    }

    public static StringProperty getItem3Property() {
        if (!(inventory.size() <= 2)) {
            return inventory.get(2).getNameProperty();
        }
        StringProperty temp = new SimpleStringProperty(" ");
        return temp;
    }

    public static StringProperty getItem4Property() {
        if (!(inventory.size() <= 3)) {
            return inventory.get(3).getNameProperty();
        }
        StringProperty temp = new SimpleStringProperty(" ");
        return temp;
    }

    public static StringProperty getItem5Property() {
        if (!(inventory.size() <= 4)) {
            return inventory.get(4).getNameProperty();
        }
        StringProperty temp = new SimpleStringProperty(" ");
        return temp;
    }

    /**
     * @return the head
     */
    public static StringProperty getHeadProperty() {
        if (head != null) {
            return head.getNameProperty();
        }
        StringProperty temp = new SimpleStringProperty(" ");
        return temp;
    }

    /**
     * @param head the head to set
     */
    public static void setHead(GamePiece head) {
        setHead(head);
    }

    /**
     * @return the chest
     */
    public static StringProperty getChestProperty() {
        if (chest != null) {
            return head.getNameProperty();
        }
        StringProperty temp = new SimpleStringProperty(" ");
        return temp;
    }

    /**
     * @param chest the chest to set
     */
    public static void setChest(GamePiece chest) {
        setChest(chest);
    }

    /**
     * @return the boots
     */
    public static StringProperty getBootsProperty() {
        if (boots != null) {
            return head.getNameProperty();
        }
        StringProperty temp = new SimpleStringProperty(" ");
        return temp;
    }

    /**
     * @param boots the boots to set
     */
    public static void setBoots(GamePiece boots) {
        setBoots(boots);
    }

}

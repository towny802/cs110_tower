
import java.util.ArrayList;
import java.util.Arrays;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;

/**
 *
 * @author Ben Spenciner
 */
public class RunGame extends Application {

    public static int index = 0;

    @Override
    public void start(Stage primaryStage) {

        Image floorImg = new Image("floor.png");
        TowerModel tower = new TowerModel();
        Player hero = new Player(new int[]{1, 1});
        Pane pane = new Pane();
        TextFlow inventoryPane = new TextFlow();
        inventoryPane.setPrefSize(320, 320);
        inventoryPane.setStyle("-fx-background-color: black");
        HBox overallPane = new HBox();

        pane.setPrefSize(640, 640);
        overallPane.getChildren().add(pane);
        overallPane.getChildren().add(inventoryPane);

        ImageView iv2 = new ImageView();
        pane.getChildren().add(iv2);

        iv2.setImage(floorImg);
        iv2.setFitHeight(640);
        iv2.setFitWidth(640);
        iv2.setX(0);
        iv2.setY(0);
        tower.AllocateFloor(tower.floor0, tower.occupants, pane);
        ImageView iv1 = new ImageView();

        iv1.setImage(hero.getImgRepresentation());
        iv1.setFitWidth(32);
        iv1.setFitHeight(32);
        iv1.setX(hero.pos[0] * (640 / 20));
        iv1.setY(hero.pos[1] * (640 / 20));

        Text playerHpLabel = new Text();
        playerHpLabel.setText("Your Stats:\nHP: ");
        playerHpLabel.setFill(Color.WHITE);
        playerHpLabel.setFont(Font.font("Verdana", 25));

        Text playerHpValue = new Text();
        playerHpValue.textProperty().bind(hero.getHealthProperty());
        playerHpValue.setFill(Color.WHITE);
        playerHpValue.setFont(Font.font("Verdana", 25));

        Text playerHpMax = new Text();
        playerHpMax.setText("/20\n");
        playerHpMax.setFill(Color.WHITE);
        playerHpMax.setFont(Font.font("Verdana", 25));

        Text playerArmorLabel = new Text();
        playerArmorLabel.setText("Armor: ");
        playerArmorLabel.setFill(Color.WHITE);
        playerArmorLabel.setFont(Font.font("Verdana", 25));

        Text playerArmorValue = new Text();
        playerArmorValue.textProperty().bind(hero.getArmorProperty());
        playerArmorValue.setFill(Color.WHITE);
        playerArmorValue.setFont(Font.font("Verdana", 25));

        Text playerDamageLabel = new Text();
        playerDamageLabel.setText("\nDamage: ");
        playerDamageLabel.setFill(Color.WHITE);
        playerDamageLabel.setFont(Font.font("Verdana", 25));

        Text playerDamageValue = new Text();
        playerDamageValue.textProperty().bind(hero.getDamageProperty());
        playerDamageValue.setFill(Color.WHITE);
        playerDamageValue.setFont(Font.font("Verdana", 25));

        Text equipmentLabel = new Text();
        equipmentLabel.setText("\n\n(e) Equipped:\n");
        equipmentLabel.setFill(Color.WHITE);
        equipmentLabel.setFont(Font.font("Verdana", 20));

        Text equipmentHeadLabel = new Text();
        equipmentHeadLabel.setText("(1) Head: ");
        equipmentHeadLabel.setFill(Color.WHITE);
        equipmentHeadLabel.setFont(Font.font("Verdana", 20));

        Text equipmentHeadValue = new Text();
        equipmentHeadValue.textProperty().bind(Inventory.getHeadProperty());
        equipmentHeadValue.setFill(Color.WHITE);
        equipmentHeadValue.setFont(Font.font("Verdana", 20));

        Text equipmentChestLabel = new Text();
        equipmentChestLabel.setText("\n(2) Chest: ");
        equipmentChestLabel.setFill(Color.WHITE);
        equipmentChestLabel.setFont(Font.font("Verdana", 20));

        Text equipmentChestValue = new Text();
        equipmentChestValue.textProperty().bind(Inventory.getChestProperty());
        equipmentChestValue.setFill(Color.WHITE);
        equipmentChestValue.setFont(Font.font("Verdana", 20));

        Text equipmentBootsLabel = new Text();
        equipmentBootsLabel.setText("\n(3) Boots: ");
        equipmentBootsLabel.setFill(Color.WHITE);
        equipmentBootsLabel.setFont(Font.font("Verdana", 20));

        Text equipmentBootsValue = new Text();
        equipmentBootsValue.textProperty().bind(Inventory.getBootsProperty());
        equipmentBootsValue.setFill(Color.WHITE);
        equipmentBootsValue.setFont(Font.font("Verdana", 20));

        Text inventoryLabel = new Text();
        inventoryLabel.setText("\n\n(i) Inventory: \n");
        inventoryLabel.setFill(Color.WHITE);
        inventoryLabel.setFont(Font.font("Verdana", 20));

        Text inventoryItem1Label = new Text();
        inventoryItem1Label.setText("(1): ");
        inventoryItem1Label.setFill(Color.WHITE);
        inventoryItem1Label.setFont(Font.font("Verdana", 20));

        Text inventoryItem1Value = new Text();
        inventoryItem1Value.textProperty().bind(Inventory.getItem1Property());
        inventoryItem1Value.setFill(Color.WHITE);
        inventoryItem1Value.setFont(Font.font("Verdana", 20));

        Text inventoryItem2Label = new Text();
        inventoryItem2Label.setText("\n(2): ");
        inventoryItem2Label.setFill(Color.WHITE);
        inventoryItem2Label.setFont(Font.font("Verdana", 20));

        Text inventoryItem2Value = new Text();
        inventoryItem2Value.textProperty().bind(Inventory.getItem2Property());
        inventoryItem2Value.setFill(Color.WHITE);
        inventoryItem2Value.setFont(Font.font("Verdana", 20));

        Text inventoryItem3Label = new Text();
        inventoryItem3Label.setText("\n(3): ");
        inventoryItem3Label.setFill(Color.WHITE);
        inventoryItem3Label.setFont(Font.font("Verdana", 20));

        Text inventoryItem3Value = new Text();
        inventoryItem3Value.textProperty().bind(Inventory.getItem3Property());
        inventoryItem3Value.setFill(Color.WHITE);
        inventoryItem3Value.setFont(Font.font("Verdana", 20));

        Text inventoryItem4Label = new Text();
        inventoryItem4Label.setText("\n(4): ");
        inventoryItem4Label.setFill(Color.WHITE);
        inventoryItem4Label.setFont(Font.font("Verdana", 20));

        Text inventoryItem4Value = new Text();
        inventoryItem4Value.textProperty().bind(Inventory.getItem4Property());
        inventoryItem4Value.setFill(Color.WHITE);
        inventoryItem4Value.setFont(Font.font("Verdana", 20));

        Text inventoryItem5Label = new Text();
        inventoryItem5Label.setText("\n(5): ");
        inventoryItem5Label.setFill(Color.WHITE);
        inventoryItem5Label.setFont(Font.font("Verdana", 20));

        Text inventoryItem5Value = new Text();
        inventoryItem5Value.textProperty().bind(Inventory.getItem5Property());
        inventoryItem5Value.setFill(Color.WHITE);
        inventoryItem5Value.setFont(Font.font("Verdana", 20));

        Text commandList = new Text();
        commandList.setText("\n\n(w): wield/wear\n(d): drop item\n(u): unequip\n(q): exit inventory\n(?): print command list");
        commandList.setFill(Color.WHITE);
        commandList.setFont(Font.font("Verdana", 20));

        inventoryPane.getChildren().addAll(playerHpLabel, playerHpValue, playerHpMax, playerArmorLabel, playerArmorValue, playerDamageLabel, playerDamageValue, equipmentLabel, equipmentHeadLabel, equipmentHeadValue, equipmentChestLabel, equipmentChestValue, equipmentBootsLabel, equipmentBootsValue, inventoryLabel, inventoryItem1Label, inventoryItem1Value, inventoryItem2Label, inventoryItem2Value, inventoryItem3Label, inventoryItem3Value, inventoryItem4Label, inventoryItem4Value, inventoryItem5Label, inventoryItem5Value, commandList);
        pane.getChildren().add(iv1);
        Scene scene = new Scene(overallPane);
        primaryStage.setScene(scene);
        primaryStage.show();

        iv1.setOnKeyPressed((KeyEvent e) -> {
            switch (e.getCode()) {
                case UP:
                    if (tower.obstructions[hero.pos[0]][hero.pos[1] - 1] instanceof Wall) {
                    } else if (tower.obstructions[hero.pos[0]][hero.pos[1] - 1] instanceof Creature) {
                        if (hero.attack(hero, tower.obstructions[hero.pos[0]][hero.pos[1] - 1])) {
                            Creature creatureTemp = (Creature) tower.obstructions[hero.pos[0]][hero.pos[1] - 1];
                            tower.occupants.remove(creatureTemp);
                            pane.getChildren().remove(creatureTemp.view);
                            Item itemTemp = creatureTemp.dropItem(creatureTemp);
                            tower.obstructions[hero.pos[0]][hero.pos[1] - 1] = itemTemp;
                            tower.occupants.add(itemTemp);
                            itemTemp.view.setFitHeight(32);
                            itemTemp.view.setFitWidth(32);
                            itemTemp.view.setX(hero.pos[0] * (640 / 20));
                            itemTemp.view.setY((hero.pos[1] - 1) * (640 / 20));
                            pane.getChildren().add(itemTemp.view);
                        }
                    } else {
                        int[] move = {0, -1};
                        hero.rePos(move, iv1);
                        hero.setHealth(hero.getHealth() - 1);
                        System.out.println(hero.getHealth());
                    }
                    break;
                case DOWN:
                    if (tower.obstructions[hero.pos[0]][hero.pos[1] + 1] instanceof Wall) {
                    } else if (tower.obstructions[hero.pos[0]][hero.pos[1] + 1] instanceof Creature) {
                        if (hero.attack(hero, tower.obstructions[hero.pos[0]][hero.pos[1] + 1])) {
                            Creature creatureTemp = (Creature) tower.obstructions[hero.pos[0]][hero.pos[1] + 1];
                            tower.occupants.remove(creatureTemp);
                            pane.getChildren().remove(creatureTemp.view);
                            Item itemTemp = creatureTemp.dropItem(creatureTemp);
                            tower.obstructions[hero.pos[0]][hero.pos[1] + 1] = itemTemp;
                            tower.occupants.add(itemTemp);
                            itemTemp.view.setFitHeight(32);
                            itemTemp.view.setFitWidth(32);
                            itemTemp.view.setX(hero.pos[0] * (640 / 20));
                            itemTemp.view.setY((hero.pos[1] + 1) * (640 / 20));
                            pane.getChildren().add(itemTemp.view);
                        }
                    } else {
                        int[] move = {0, 1};
                        hero.rePos(move, iv1);
                    }
                    break;
                case LEFT:
                    if (tower.obstructions[hero.pos[0] - 1][hero.pos[1]] instanceof Wall) {
                    } else if (tower.obstructions[hero.pos[0] - 1][hero.pos[1]] instanceof Creature) {
                        if (hero.attack(hero, tower.obstructions[hero.pos[0] - 1][hero.pos[1]])) {
                            Creature creatureTemp = (Creature) tower.obstructions[hero.pos[0] - 1][hero.pos[1]];
                            tower.occupants.remove(creatureTemp);
                            pane.getChildren().remove(creatureTemp.view);
                            Item itemTemp = creatureTemp.dropItem(creatureTemp);
                            tower.obstructions[hero.pos[0] - 1][hero.pos[1]] = itemTemp;
                            tower.occupants.add(itemTemp);
                            itemTemp.view.setFitHeight(32);
                            itemTemp.view.setFitWidth(32);
                            itemTemp.view.setX((hero.pos[0] - 1) * (640 / 20));
                            itemTemp.view.setY(hero.pos[1] * (640 / 20));
                            pane.getChildren().add(itemTemp.view);
                        }
                    } else {
                        int[] move = {-1, 0};
                        hero.rePos(move, iv1);
                    }
                    break;
                case RIGHT:
                    if (tower.obstructions[hero.pos[0] + 1][hero.pos[1]] instanceof Wall) {
                    } else if (tower.obstructions[hero.pos[0] + 1][hero.pos[1]] instanceof Creature) {
                        if (hero.attack(hero, tower.obstructions[hero.pos[0] + 1][hero.pos[1]])) {
                            Creature creatureTemp = (Creature) tower.obstructions[hero.pos[0] + 1][hero.pos[1]];
                            tower.occupants.remove(creatureTemp);
                            pane.getChildren().remove(creatureTemp.view);
                            Item itemTemp = creatureTemp.dropItem(creatureTemp);
                            tower.obstructions[hero.pos[0] + 1][hero.pos[1]] = itemTemp;
                            tower.occupants.add(itemTemp);
                            itemTemp.view.setFitHeight(32);
                            itemTemp.view.setFitWidth(32);
                            itemTemp.view.setX((hero.pos[0] + 1) * (640 / 20));
                            itemTemp.view.setY(hero.pos[1] * (640 / 20));
                            pane.getChildren().add(itemTemp.view);
                        }
                    } else {
                        int[] move = {1, 0};
                        hero.rePos(move, iv1);
                    }
                    break;
                case Y:
                    if (tower.obstructions[hero.pos[0] - 1][hero.pos[1] - 1] instanceof Wall) {
                    } else if (tower.obstructions[hero.pos[0] - 1][hero.pos[1] - 1] instanceof Creature) {
                        if (hero.attack(hero, tower.obstructions[hero.pos[0] - 1][hero.pos[1] - 1])) {
                            Creature creatureTemp = (Creature) tower.obstructions[hero.pos[0] - 1][hero.pos[1] - 1];
                            tower.occupants.remove(creatureTemp);
                            pane.getChildren().remove(creatureTemp.view);
                            Item itemTemp = creatureTemp.dropItem(creatureTemp);
                            tower.obstructions[hero.pos[0] - 1][hero.pos[1] - 1] = itemTemp;
                            tower.occupants.add(itemTemp);
                            itemTemp.view.setFitHeight(32);
                            itemTemp.view.setFitWidth(32);
                            itemTemp.view.setX((hero.pos[0] - 1) * (640 / 20));
                            itemTemp.view.setY((hero.pos[1] - 1) * (640 / 20));
                            pane.getChildren().add(itemTemp.view);
                        }
                    } else {
                        int[] move = {-1, -1};
                        hero.rePos(move, iv1);
                    }
                    break;
                case U:
                    if (tower.obstructions[hero.pos[0] + 1][hero.pos[1] - 1] instanceof Wall) {
                    } else if (tower.obstructions[hero.pos[0] + 1][hero.pos[1] - 1] instanceof Creature) {
                        if (hero.attack(hero, tower.obstructions[hero.pos[0] + 1][hero.pos[1] - 1])) {
                            Creature creatureTemp = (Creature) tower.obstructions[hero.pos[0] + 1][hero.pos[1] - 1];
                            tower.occupants.remove(creatureTemp);
                            pane.getChildren().remove(creatureTemp.view);
                            Item itemTemp = creatureTemp.dropItem(creatureTemp);
                            tower.obstructions[hero.pos[0] + 1][hero.pos[1] - 1] = itemTemp;
                            tower.occupants.add(itemTemp);
                            itemTemp.view.setFitHeight(32);
                            itemTemp.view.setFitWidth(32);
                            itemTemp.view.setX((hero.pos[0] + 1) * (640 / 20));
                            itemTemp.view.setY((hero.pos[1] - 1) * (640 / 20));
                            pane.getChildren().add(itemTemp.view);
                        }
                    } else {
                        int[] move = {1, -1};
                        hero.rePos(move, iv1);
                    }
                    break;
                case B:
                    if (tower.obstructions[hero.pos[0] - 1][hero.pos[1] + 1] instanceof Wall) {
                    } else if (tower.obstructions[hero.pos[0] - 1][hero.pos[1] + 1] instanceof Creature) {
                        if (hero.attack(hero, tower.obstructions[hero.pos[0] - 1][hero.pos[1] + 1])) {
                            Creature creatureTemp = (Creature) tower.obstructions[hero.pos[0] - 1][hero.pos[1] + 1];
                            tower.occupants.remove(creatureTemp);
                            pane.getChildren().remove(creatureTemp.view);
                            Item itemTemp = creatureTemp.dropItem(creatureTemp);
                            tower.obstructions[hero.pos[0] - 1][hero.pos[1] + 1] = itemTemp;
                            tower.occupants.add(itemTemp);
                            itemTemp.view.setFitHeight(32);
                            itemTemp.view.setFitWidth(32);
                            itemTemp.view.setX((hero.pos[0] - 1) * (640 / 20));
                            itemTemp.view.setY((hero.pos[1] + 1) * (640 / 20));
                            pane.getChildren().add(itemTemp.view);
                        }
                    } else {
                        int[] move = {-1, 1};
                        hero.rePos(move, iv1);
                    }
                    break;
                case N:
                    if (tower.obstructions[hero.pos[0] + 1][hero.pos[1] + 1] instanceof Wall) {
                    } else if (tower.obstructions[hero.pos[0] + 1][hero.pos[1] + 1] instanceof Creature) {
                        if (hero.attack(hero, tower.obstructions[hero.pos[0] + 1][hero.pos[1] + 1])) {
                            Creature creatureTemp = (Creature) tower.obstructions[hero.pos[0] + 1][hero.pos[1] + 1];
                            tower.occupants.remove(creatureTemp);
                            pane.getChildren().remove(creatureTemp.view);
                            Item itemTemp = creatureTemp.dropItem(creatureTemp);
                            tower.obstructions[hero.pos[0] + 1][hero.pos[1] + 1] = itemTemp;
                            tower.occupants.add(itemTemp);
                            itemTemp.view.setFitHeight(32);
                            itemTemp.view.setFitWidth(32);
                            itemTemp.view.setX((hero.pos[0] + 1) * (640 / 20));
                            itemTemp.view.setY((hero.pos[1] + 1) * (640 / 20));
                            pane.getChildren().add(itemTemp.view);
                        }
                    } else {
                        int[] move = {1, 1};
                        hero.rePos(move, iv1);
                    }
                    break;
                case I:

                    break;
                case COMMA:
                    if (tower.obstructions[hero.pos[0]][hero.pos[1]] instanceof Item) {
                        if (Inventory.addItem((Item) tower.obstructions[hero.pos[0]][hero.pos[1]])) {
                            tower.occupants.remove(tower.obstructions[hero.pos[0]][hero.pos[1]]);
                            pane.getChildren().remove(tower.obstructions[hero.pos[0]][hero.pos[1]].view);
                            tower.obstructions[hero.pos[0]][hero.pos[1]] = null;
                            System.out.println(Inventory.inventoryToString());
                        }
                    }
                    break;
                case ESCAPE:
                    break;
                case PERIOD:
                    if (tower.obstructions[hero.pos[0]][hero.pos[1]] instanceof downLadder) {
                        tower.travelFloor(index, hero, pane, iv2);
                    } else if (tower.obstructions[hero.pos[0]][hero.pos[1]] instanceof upLadder) {
                        tower.travelFloor(index, hero, pane, iv2);
                    }
                    break;
                default:
                    System.out.println("Key not mapped.");
            }
            System.out.println(Arrays.toString(hero.pos));
        });
        iv1.requestFocus();

//        Graph graph = new Graph(tower.obstructions);
//        System.out.println(graph.toString());
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}


/**
 *
 * @author Ben Spenciner
 */
public abstract class Weapon extends Item {

}

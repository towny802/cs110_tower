
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.image.Image;

/**
 *
 * @author Ben Spenciner
 */
public class Player extends GamePiece {

    private char charRepresentation = 'X';
    private Image imgRepresentation = new Image("player.png");
    private StringProperty health = new SimpleStringProperty("20");
    private StringProperty damage = new SimpleStringProperty("2");
    private StringProperty armor = new SimpleStringProperty("2");
    private String name = "Default";

    public Player(int[] pos) {
        super(pos);
        health.setValue("20");
    }
    
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getName() {
        return name;
    }

    public void setCharRepresentation(char charRepresentation) {
        this.charRepresentation = charRepresentation;
    }

    public void setImgRepresentation(Image imgRepresentation) {
        this.imgRepresentation = imgRepresentation;
    }

    @Override
    public char getCharRepresentation() {
        return charRepresentation;
    }

    @Override
    public Image getImgRepresentation() {
        return imgRepresentation;
    }

    /**
     * @return the health
     */
    @Override
    public int getHealth() {
        return Integer.parseInt(health.getValue());
    }
    public StringProperty getHealthProperty() {
        return health;
    }
    /**
     * @param health the health to set
     */
    @Override
    public void setHealth(int health) {
        this.health.setValue(Integer.toString(health));
    }
    /**
     * @return the armor
     */
    @Override
    public int getArmor() {
        return Integer.parseInt(armor.getValue());
    }
    public StringProperty getArmorProperty() {
        return armor;
    }
    /**
     * @param armor the armor to set
     */
    @Override
    public void setArmor(int armor) {
        this.armor.setValue(Integer.toString(armor));
    }
    
    /**
     * @return the damage
     */
    @Override
    public int getDamage() {
        return Integer.parseInt(damage.getValue());
    }
    public StringProperty getDamageProperty() {
        return damage;
    }
    /**
     * @param damage the damage to set
     */
    @Override
    public void setDamage(int damage) {
        this.damage.setValue(Integer.toString(damage));
    }
}

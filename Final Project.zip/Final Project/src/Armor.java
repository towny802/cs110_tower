
/**
 *
 * @author Ben Spenciner
 */
public abstract class Armor extends Item {

}
